PolicyWell — YC Product Demo (3:00)
=====================================

PRIMARY DOWNLOAD (recommended for YC upload)
--------------------------------------------
PolicyWell-YC-Demo-3min.mp4
  Full 3:00 screen recording of the interactive product demo.
  Well under 100MB.

PolicyWell-YC-Demo-preview.gif
  Short animated preview clip.

LIVE INTERACTIVE DEMO
---------------------
https://policywell.ai/product/

ALSO IN THIS ZIP
----------------
- README.txt / TIMING.txt / offline-demo.html / SIZE-NOTE.txt
- The MP4 and GIF when present in public/downloads/

CONTACT
-------
https://policywell.ai/book-a-call/
