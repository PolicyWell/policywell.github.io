PolicyWell — YC Product Demo (3:00)
=====================================

WHAT THIS IS
------------
A lightweight, downloadable companion to the interactive PolicyWell product
demo used for YC applications. No video file — CSS/HTML only — well under
the 100MB limit.

LIVE INTERACTIVE DEMO (recommended for partners)
------------------------------------------------
https://policywell.ai/product/

Open that URL and press Play. Autoplay walks every feature step-by-step
in exactly 3:00. You can Pause, Next/Prev, or click the rail to jump.

OFFLINE FILES IN THIS ZIP
-------------------------
- README.txt          This file
- TIMING.txt          Second-by-second beat sheet (3:00)
- offline-demo.html   Offline step player (open in any browser)
- SIZE-NOTE.txt       Confirms package stays under 100MB

SIZE
----
This package is intentionally tiny (HTML/text only, no video/audio).
Target: well under 100MB for YC upload limits.

CONTACT
-------
https://policywell.ai/book-a-call/
